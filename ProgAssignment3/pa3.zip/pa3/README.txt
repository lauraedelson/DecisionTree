To compile:
 g++ -std=c++0x Node.h Reviewer.h ChanceNode.h DecisionNode.h LeafNode.h DecisionTree.h Reviewer.h ChanceNode.cpp DecisionNode.cpp DecisionTree.cpp main.cpp -o DecisionTree

To run:
./DecisionTree input.txt

Output will be as specified in the assignment spec. When responding, type 'Yes' or 'No' to specify whether 
the reviewer has accepted or rejected the book.